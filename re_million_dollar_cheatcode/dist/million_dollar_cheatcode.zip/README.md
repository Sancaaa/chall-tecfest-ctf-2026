# TecFest26 - Million Dollar Cheatcode

Welcome, challenger!

Your mission is to uncover the hidden flag within this game.

## How to Run

1. Extract the ZIP archive.
2. Open the folder for your operating system.
3. Run the game executable.
4. Start playing and investigate the game.

## Game Controls

| Key | Action |
|---|---|
| A | Move Left |
| D | Move Right |
| S | Crouch |
| Enter | Jump |
| `'` (Apostrophe) | Dash |
| `/` (Slash) | Shoot |

> Note: The exact key position may depend on your keyboard layout.

## Objective

Find the hidden flag.

**Flag Format:** `TecFest26{...}`

Good luck, and happy hunting!

**Organized by TecFest26**
